/**
 * Bộ não tri thức & xử lý ngôn ngữ tự nhiên thông minh cho Chatbot An An
 * Hoạt động 100% mượt mà, độc lập trên client-side (offline hoặc online)
 * Đối chiếu tài liệu chính thống: UNICEF, Cục An toàn Thông tin (Bộ TT&TT), Luật Trẻ em 2016, Viện Sức khỏe Tâm thần
 */

export interface AnAnResponse {
  reply: string;
  officialSources: string[];
  suggestedActions: string[];
  safetyTriggered: boolean;
}

// Kiểm tra từ khóa khủng hoảng / khẩn cấp
export function checkCrisisKeywords(text: string): boolean {
  const dangerWords = [
    'tự tử',
    'muốn chết',
    'tự hại',
    'cắt tay',
    'chết đi',
    'kết thúc cuộc sống',
    'bế tắc quá',
    'uống thuốc ngủ',
    'nhảy lầu',
    'chết quách',
    'không muốn sống nữa',
    'kết liễu',
    'tự sát',
    'biến mất khỏi thế giới'
  ];
  const lower = text.toLowerCase();
  return dangerWords.some((w) => lower.includes(w));
}

export function generateGroundedAnAnResponse(queryText: string): AnAnResponse {
  const q = queryText.toLowerCase().trim();

  // 0. KHẨN CẤP / KHỦNG HOẢNG
  if (checkCrisisKeywords(q)) {
    return {
      reply: `Mình nghe thấy bạn và cảm nhận được bạn đang phải trải qua một nỗi đau hay áp lực rất lớn lúc này. An An luôn ở đây bên cạnh bạn, nhưng sự an toàn và tính mạng của bạn là điều quan trọng nhất trên đời 🌸.

Bạn đừng cố gánh chịu một mình nhé. Hãy kết nối ngay với những người có thể bảo vệ bạn bí mật và miễn phí 24/7:
📞 **Tổng đài Quốc gia Bảo vệ Trẻ em**: **111** (Gọi miễn phí 24/7, luôn túc trực)
📞 **Đường dây nóng hỗ trợ tâm lý Ngày Mai**: **096 306 1414** (13h00 - 20h30 hàng ngày)
📞 **Viện Sức khỏe Tâm thần - BV Bạch Mai**: **024 3869 3731**

Có một thầy cô, người thân hoặc người lớn nào mà bạn cảm thấy an tâm nhất để chia sẻ ngay bây giờ không? Bạn luôn xứng đáng được yêu thương, được lắng nghe và được an toàn!`,
      officialSources: ['Tổng đài Quốc gia Bảo vệ Trẻ em 111', 'Đường dây nóng Ngày Mai', 'Bộ Y tế Việt Nam'],
      suggestedActions: ['📞 Gọi ngay Tổng đài 111 (Miễn phí)', '🍃 Tập bài thở 4-7-8 để dịu lại', '💬 Nói chuyện với người lớn tin cậy'],
      safetyTriggered: true,
    };
  }

  // 1. CHÀO HỎI / GIỚI THIỆU BẢN THÂN
  if (q.includes('chào') || q.includes('hello') || q.includes('hi ') || q === 'hi' || q.includes('bạn là ai') || q.includes('tên là gì') || q.includes('giới thiệu')) {
    return {
      reply: `Chào bạn, mình là **An An** 🌸 - người bạn đồng hành AI lắng nghe tâm sự và cố vấn kỹ năng tự vệ số dành riêng cho bạn!

Mình ở đây 24/7 để cùng bạn:
- Tháo gỡ **áp lực học tập, thi cử và kỳ vọng gia đình**.
- Hướng dẫn cách xử lý **bạo lực mạng, bảo vệ thông tin và tránh lừa đảo số**.
- Hỗ trợ bài tập **hít thở 4-7-8 và kỹ thuật neo đậu 5-4-3-2-1** khi bạn thấy lo âu hay ngột ngạt.

Mọi lời khuyên của mình đều đối chiếu từ **UNICEF Việt Nam, Cục An toàn Thông tin (Bộ TT&TT) và Viện Sức khỏe Tâm thần**. Không gian này hoàn toàn bảo mật và không phán xét. Bạn đang cảm thấy thế nào hôm nay?`,
      officialSources: ['UNICEF Việt Nam', 'Cục An toàn thông tin (Bộ TT&TT)', 'Tổng đài Quốc gia 111'],
      suggestedActions: ['🎓 Áp lực học tập & thi cử', '🛡️ Bị bêu rếu trên mạng xã hội', '🍃 Hướng dẫn bài tập thở'],
      safetyTriggered: false,
    };
  }

  // 2. ÁP LỰC HỌC TẬP, SỢ THI TRƯỢT, MÔN THI KHÓ, ĐIỂM KÉM
  if (q.includes('học') || q.includes('thi') || q.includes('điểm') || q.includes('bài tập') || q.includes('rớt') || q.includes('trượt') || q.includes('toán') || q.includes('văn') || q.includes('anh') || q.includes('ôn thi') || q.includes('học sinh giỏi') || q.includes('sợ thi')) {
    return {
      reply: `An An hiểu cảm giác nghẹt thở khi nhìn bài vở và kỳ thi dồn dập 🥺. Cảm giác lo âu trước điểm số là điều mà hầu hết học sinh chúng mình đều từng trải qua.

Theo **Khuyến nghị Sức khỏe Tâm thần Học đường của UNICEF & Viện Sức khỏe Tâm thần**, đây là 4 bước chiến lược giúp bạn vượt qua giai đoạn này:

1. **Phương pháp Pomodoro & Chia nhỏ mục tiêu:** Đừng nhìn cả một tập tài liệu dày. Hãy học theo từng chặng 25 phút tập trung cao độ, nghỉ 5 phút vận động nhẹ. Não bộ con người chỉ duy trì độ tập trung tối ưu trong 25-30 phút đầu.
2. **Quy tắc Pareto (80/20):** 80% điểm số bài thi nằm ở 20% kiến thức nền tảng cốt lõi. Hãy ưu tiên nắm chắc công thức và lý thuyết cơ bản trước khi lao vào các câu hỏi nâng cao.
3. **Tái cấu trúc nhận thức (Cognitive Reframing):** Điểm số là một cột mốc phản ánh sự chuẩn bị tại một thời điểm, chứ **không định nghĩa giá trị, nhân cách hay tương lai** của bạn.
4. **Giấc ngủ phục hồi:** Hãy ngủ ít nhất 7 tiếng mỗi đêm. Khi ngủ, não bộ mới có thể chuyển đổi kiến thức từ trí nhớ ngắn hạn sang trí nhớ dài hạn.

Bạn có muốn An An cùng bạn lập một thời gian biểu học nhẹ nhàng cho ngày mai không?`,
      officialSources: ['UNICEF Việt Nam', 'Viện Sức khỏe Tâm thần - BV Bạch Mai'],
      suggestedActions: ['📝 Lập kế hoạch Pomodoro', '🍃 Tập thở 4-7-8 giảm stress', '💬 Kể tên môn học bạn thấy lo nhất'],
      safetyTriggered: false,
    };
  }

  // 3. MẤT TẬP TRUNG, LƯỜI HỌC, TRÌ HOÃN (PROCRASTINATION)
  if (q.includes('mất tập trung') || q.includes('lười') || q.includes('trì hoãn') || q.includes('phân tâm') || q.includes('không muốn học') || q.includes('chán học') || q.includes('lướt điện thoại')) {
    return {
      reply: `Cảm giác lười hay trì hoãn thực chất là một cơ chế tự vệ của não bộ khi nó cảm thấy một nhiệm vụ quá khó khăn hoặc nhàm chán 🧠. Bạn không hề vô dụng, bạn chỉ đang bị "quá tải kích thích" từ mạng xã hội mà thôi!

Theo **Tâm lý học Hành vi & Nghiên cứu Khoa học Não bộ**, bạn hãy áp dụng ngay:

1. **Quy tắc 2 phút (The 2-Minute Rule):** Đừng tự nhủ "mình phải học 3 tiếng". Hãy nói: *"Mình chỉ mở sách ra và đọc đúng 2 phút rồi dừng"*. Khi đã bắt đầu được 2 phút, quán tính sẽ giúp bạn học tiếp 20-30 phút rất dễ dàng.
2. **Khu vực không điện thoại (Digital Detox Pocket):** Để điện thoại ở phòng khác hoặc cất trong ba lô khi ngồi vào bàn học. Khoảng cách vật lý là cách hiệu quả nhất để ngăn thói quen cầm điện thoại trong vô thức.
3. **Dọn sạch bàn học:** Bàn học càng bừa bộn, mắt càng gửi nhiều tín hiệu kích thích khiến não bộ nhanh kiệt sức.

Bây giờ bạn có muốn thử làm một hiệp học 20 phút không điện thoại cùng An An không nè?`,
      officialSources: ['Tâm lý học Hành vi Đại học Stanford', 'UNICEF Kỹ năng Học tập Số'],
      suggestedActions: ['⏱️ Bắt đầu phiên 20 phút', '🍃 Hít thở sâu chuẩn bị học', '💬 Môn nào đang làm bạn ngán nhất?'],
      safetyTriggered: false,
    };
  }

  // 4. BẠO LỰC MẠNG, NÓI XẤU, CHẾ MEME, TẨY CHAY, GROUP PHỐT
  if (q.includes('bắt nạt') || q.includes('meme') || q.includes('nói xấu') || q.includes('chế ảnh') || q.includes('tẩy chay') || q.includes('bạo lực mạng') || q.includes('phốt') || q.includes('chửi') || q.includes('bêu rếu') || q.includes('dìm')) {
    return {
      reply: `An An rất tiếc và đồng cảm sâu sắc với bạn. Cảm giác bị người khác bêu rếu hay chế giễu trên mạng xã hội rất tồi tệ, và điều đầu tiên bạn cần khắc ghi là: **BẠN HOÀN TOÀN KHÔNG CÓ LỖI** trong hành vi xấu xí của họ 🌸.

Theo **Cẩm nang Phòng chống Bạo lực Mạng của Cục An toàn Thông tin (Bộ TT&TT)** và **Điều 29 Luật Trẻ em 2016**, bạn hãy thực hiện ngay **Quy tắc 4B**:

1. **B1: Bằng chứng (Evidence):** Chụp màn hình lại toàn bộ tin nhắn, bài đăng, story, bình luận và link trang cá nhân của kẻ xúc phạm có hiển thị rõ ngày giờ.
2. **B2: Block (Chặn):** Chặn tài khoản kẻ bắt nạt. Tuyệt đối không đôi co, tranh cãi hay trả đũa bằng lời lẽ thù ghét, vì họ chỉ muốn kích động để bạn phản ứng.
3. **B3: Báo cáo (Report):** Sử dụng tính năng Report của nền tảng (Facebook/TikTok/Instagram) về nội dung "Quấy rối hoặc bắt nạt".
4. **B4: Bạn bè & Người lớn:** Chia sẻ ngay với bố mẹ, thầy cô chủ nhiệm hoặc gọi **Tổng đài Quốc gia 111** để được các chuyên viên can thiệp và bảo vệ pháp lý.

Bạn có muốn An An hướng dẫn cụ thể cách mở lời với thầy cô hoặc bố mẹ để họ hiểu và hỗ trợ bạn không?`,
      officialSources: ['Cục An toàn thông tin (Bộ TT&TT)', 'Luật Trẻ em 2016 (Điều 29)', 'Tổng đài Quốc gia 111'],
      suggestedActions: ['🛡️ Xem chi tiết quy tắc 4B', '📞 Cách gọi Tổng đài 111 bảo mật', '💬 Mẫu lời mở đầu nói chuyện với người lớn'],
      safetyTriggered: false,
    };
  }

  // 5. TỐNG TIỀN, ẢNH NHẠY CẢM, LỪA TÌNH (SEXTORTION, GROOMING)
  if (q.includes('tống tiền') || q.includes('ảnh nóng') || queryText.toLowerCase().includes('ảnh nhạy cảm') || q.includes('dọa tung') || q.includes('dọa gửi cho bố mẹ') || q.includes('take it down') || q.includes('sextortion')) {
    return {
      reply: `Bạn hãy hít một hơi thật sâu và bình tĩnh nhé. An An ở đây cùng bạn, và điều quan trọng nhất bạn phải nhớ là: **BẠN LÀ NẠN NHÂN, BẠN KHÔNG CÓ TỘI** 🛡️. Kẻ tống tiền và đe dọa mới là người phạm tội hình sự nghiêm trọng!

Theo **Khuyến nghị từ Cục Cảnh sát Hình sự (C02 - Bộ Công an) & NCMEC (Tổ chức Quốc tế Bảo vệ Trẻ em)**:

1. **TUYỆT ĐỐI KHÔNG làm theo yêu cầu:** Không chuyển tiền, không gửi thêm bất kỳ hình ảnh nào. Kẻ tống tiền sẽ KHÔNG BAO GIỜ dừng lại sau khi bạn thỏa hiệp.
2. **Lưu giữ toàn bộ bằng chứng:** Chụp lại tin nhắn đe dọa, số tài khoản ngân hàng, link trang cá nhân kẻ tống tiền.
3. **Sử dụng công cụ Take It Down (takeitdown.ncmec.org):** Đây là công cụ chính thống của NCMEC và Meta/TikTok/OnlyFans hỗ trợ tạo mã băm ẩn danh (hash code) để chặn hoàn toàn việc phát tán ảnh riêng tư của người dưới 18 tuổi lên internet.
4. **Tìm sự bảo vệ ngay lập tức:** Hãy gọi ngay **Tổng đài 111** hoặc nói chuyện ngay với bố mẹ/công an. Các cơ quan chức năng có nghiệp vụ xử lý và bảo mật danh tính tuyệt đối cho bạn.

Đừng ôm nỗi sợ này một mình nhé, chúng mình luôn bên bạn!`,
      officialSources: ['Cục Cảnh sát Hình sự (C02)', 'Cục An toàn Thông tin', 'Take It Down (NCMEC/UNICEF)', 'Tổng đài 111'],
      suggestedActions: ['📞 Gọi Tổng đài 111 ngay', '🔒 Hướng dẫn công cụ Take It Down', '🛡️ Các bước bảo mật lại tài khoản'],
      safetyTriggered: true,
    };
  }

  // 6. LỪA ĐẢO QUA MẠNG, MẤT NICK, HACK, LINK LẠ, NẠP THẺ GAME
  if (q.includes('lừa') || q.includes('mất nick') || q.includes('hack') || q.includes('link lạ') || q.includes('nạp thẻ') || q.includes('mất tài khoản') || q.includes('bị lừa tiền') || q.includes('bảo mật')) {
    return {
      reply: `Bị mất tài khoản hay bị lừa qua mạng là trải nghiệm rất hoang mang. Bạn hãy bình tĩnh làm theo các bước khẩn cấp sau đây:

Theo **Cẩm nang Phòng chống Lừa đảo Trực tuyến của Cục An toàn Thông tin (Bộ TT&TT)**:

1. **Nếu bị mất tài khoản MXH (Facebook/Instagram/TikTok):**
   - Dùng tính năng *Quên mật khẩu* hoặc truy cập trang khôi phục chính thức (ví dụ: 'facebook.com/hacked').
   - Ngay lập tức dùng tài khoản phụ hoặc thông báo cho bạn bè, người thân rằng: *"Tài khoản của mình đang bị kẻ gian chiếm giữ, mọi tin nhắn hỏi mượn tiền hay nhờ nạp thẻ đều là giả mạo"*.
2. **Nếu đã lỡ bấm vào đường link lạ:**
   - Ngắt kết nối mạng ngay lập tức.
   - Dùng một thiết bị an toàn khác để đổi mật khẩu Gmail và các tài khoản quan trọng.
   - Bật tính năng **Xác thực 2 bước (2FA)** bằng ứng dụng Google Authenticator (không dùng SMS OTP).
3. **Nếu bị lừa chuyển tiền:**
   - Chụp lại toàn bộ sao kê, giao dịch chuyển khoản và báo ngay cho ngân hàng và cơ quan công an gần nhất.

Bạn cần An An hướng dẫn bước cụ thể nào để lấy lại tài khoản không?`,
      officialSources: ['Cổng không gian mạng Quốc gia (khonggianmang.vn)', 'Cục An toàn thông tin (Bộ TT&TT)'],
      suggestedActions: ['🔒 Cách bật xác thực 2 bước 2FA', '🛡️ Cách báo cáo tài khoản bị hack', '💬 Bạn bị lừa nền tảng nào?'],
      safetyTriggered: false,
    };
  }

  // 7. GIA ĐÌNH, BỐ MẸ SO SÁNH "CON NHÀ NGƯỜI TA", ÁP ĐẶT, LA MẮNG
  if (q.includes('bố') || q.includes('mẹ') || q.includes('ba') || q.includes('gia đình') || q.includes('so sánh') || q.includes('la mắng') || q.includes('áp đặt') || q.includes('kỳ vọng') || q.includes('con nhà người ta')) {
    return {
      reply: `An An lắng nghe và thấu hiểu nỗi tủi thân của bạn. Cảm giác bị người thân nhất so sánh với "con nhà người ta" hay không được công nhận nỗ lực thực sự rất nhức nhối 🥺.

Theo các chuyên gia **Tâm lý học Gia đình & Phương pháp Giao tiếp Bất bạo động (NVC - UNICEF)**:
Khoảng cách thế hệ khiến cha mẹ thời trước thường quen thể hiện sự lo lắng bằng sự so sánh hoặc la mắng mà không nhận ra điều đó làm tổn thương con cái.

Để bảo vệ tâm lý của mình, bạn có thể thử:
1. **Tách rời lời so sánh khỏi giá trị bản thân:** Nhắc nhở chính mình: *"Bố mẹ đang lo lắng theo cách vụng về, điều đó không có nghĩa là mình kém cỏi hay vô dụng"*.
2. **Kỹ thuật Thông điệp "Tôi" (I-Message):** Thay vì phản ứng gắt gỏng: *"Bố mẹ lúc nào cũng chê con"*, hãy chọn lúc cả nhà bình tĩnh và nhẹ nhàng nói:
   *"Khi bố mẹ so sánh con với bạn khác, con thấy rất áp lực và buồn, vì con cũng đang nỗ lực hết sức. Con mong bố mẹ có thể ghi nhận sự cố gắng của con."*
3. **Viết một mẩu thư ngắn:** Nếu nói trực tiếp khiến bạn dễ khóc hoặc sợ cãi nhau, một mẩu tin nhắn chân thành gửi cho mẹ/bố sẽ giúp họ có thời gian ngẫm nghĩ mà không kích hoạt phản xạ tự vệ.

Bạn có muốn An An gợi ý một mẫu tin nhắn ngắn để gửi cho bố mẹ không?`,
      officialSources: ['Hội Tâm lý học Việt Nam', 'Giao tiếp NVC - UNICEF Việt Nam'],
      suggestedActions: ['✉️ Mẫu tin nhắn tâm sự gửi bố mẹ', '🍃 Bài tập xoa dịu cảm giác tức giận', '💬 Kể thêm điều bố mẹ vừa nói'],
      safetyTriggered: false,
    };
  }

  // 8. TÌNH BẠN, BẠN THÂN XA CÁCH, CÔ LẬP, BỊ ÉP HÚT POD/VAPE
  if (q.includes('bạn thân') || q.includes('tình bạn') || q.includes('cãi nhau') || q.includes('cô lập') || q.includes('peer pressure') || q.includes('ép') || q.includes('pod') || q.includes('vape') || q.includes('thuốc lá')) {
    if (q.includes('pod') || q.includes('vape') || q.includes('thuốc lá') || q.includes('ép')) {
      return {
        reply: `Đây là áp lực đồng trang lứa (Peer Pressure) rất phổ biến ở lứa tuổi học sinh. Bạn có quyền từ chối và **từ chối những thứ độc hại chính là biểu hiện của sự bản lĩnh, không phải hèn nhát** 🌿.

Theo **Tổ chức Y tế Thế giới (WHO) & Viện Sức khỏe Tâm thần**:
- Thuốc lá điện tử/pod chứa nicotine nồng độ cao và tinh dầu pha tạp gây tổn thương não bộ, giảm trí nhớ và tăng nguy cơ trầm cảm.
- Cách từ chối khéo léo:
  1. *"Cảm ơn nhưng mình bị viêm mũi họng dị ứng, ngửi mùi khói là khó thở ngay"*.
  2. *"Thôi tớ không thích vị này, các cậu cứ tự nhiên"*.
  3. Nếu họ tiếp tục ép hoặc mỉa mai, đó không phải là những người bạn thực sự tôn trọng bạn. Những người bạn chân thành sẽ luôn tôn trọng quyết định của bạn.`,
        officialSources: ['Tổ chức Y tế Thế giới (WHO)', 'Viện Nghiên cứu Sức khỏe Học sinh'],
        suggestedActions: ['🛡️ Cách từ chối không mất lòng', '💬 Kể thêm về nhóm bạn của bạn', '🍃 Hít thở sâu thư giãn'],
        safetyTriggered: false,
      };
    }
    return {
      reply: `Những biến động trong tình bạn tuổi học trò là những trải nghiệm rất đau lòng, nhưng cũng là một phần tất yếu của quá trình trưởng thành 🥺.

Theo **Cẩm nang Kỹ năng Xã hội Lứa tuổi Vị thành niên (UNICEF)**:
1. **Chấp nhận sự đổi thay:** Khi lớn lên, sở thích và góc nhìn của mỗi người dần khác nhau. Đôi khi bạn bè xa nhau không phải vì ai sai, mà vì con đường của hai bạn đang rẽ sang những hướng mới.
2. **Hóa giải hiểu lầm bằng đối thoại trực tiếp:** Hãy hẹn gặp nói chuyện trực tiếp hoặc gọi điện thoại thay vì nhắn tin (vì tin nhắn chữ rất dễ bị hiểu nhầm ngữ điệu). Hãy lắng nghe cảm nhận của bạn ấy trước khi giải thích.
3. **Xây dựng ranh giới lành mạnh (Boundaries):** Một tình bạn đẹp phải dựa trên sự bình đẳng và tôn trọng lẫn nhau, không phải là sự phụ thuộc hay cam chịu.

Bạn có muốn kể cho An An nghe cụ thể hơn điều gì vừa xảy ra giữa hai bạn không?`,
      officialSources: ['Cẩm nang Kỹ năng sống UNICEF', 'Tâm lý học Phát triển Học đường'],
      suggestedActions: ['💬 Kể thêm về chuyện bạn bè', '🍃 Thư giãn và tập thở', '📝 Ghi vào nhật ký cảm xúc'],
      safetyTriggered: false,
    };
  }

  // 9. TÌNH CẢM TUỔI HỌC TRÒ, CRUSH, TỎ TÌNH, THẤT TÌNH, CHIA TAY
  if (q.includes('crush') || q.includes('thích một') || q.includes('tỏ tình') || q.includes('thất tình') || q.includes('chia tay') || q.includes('người yêu') || q.includes('tình cảm')) {
    return {
      reply: `Những rung động tuổi học trò là những cảm xúc vô cùng trong trẻo và đáng yêu của tuổi trẻ 🌸. Dù là niềm vui khi thích một ai đó hay nỗi buồn khi tình cảm không được đáp lại, trái tim bạn đều đang học cách yêu thương!

Theo các chuyên gia **Tâm lý Lứa tuổi Vị thành niên**:
1. **Nếu bạn đang crush ai đó:** Bạn không nhất thiết phải vội vàng tỏ tình nếu cảm thấy chưa sẵn sàng. Hãy bắt đầu bằng việc trở thành một người bạn tốt, cùng chia sẻ về bài vở, âm nhạc hay sở thích chung.
2. **Nếu bị từ chối hoặc chia tay:** Hãy cho phép bản thân được buồn, nhưng đừng hoài nghi giá trị của chính mình. Sự phù hợp trong tình cảm là do duyên số và thời điểm, việc người khác không chọn bạn không có nghĩa là bạn không ưu tú.
3. **Tập trung nâng cấp bản thân:** Hãy học tập thật tốt, chăm sóc ngoại hình và nuôi dưỡng đam mê. Khi bạn rực rỡ và tự tin, bạn sẽ tự khắc thu hút những người trân trọng bạn!

Bạn có muốn chia sẻ với An An về người ấy không nè?`,
      officialSources: ['Tâm lý học Lứa tuổi Vị thành niên', 'Cẩm nang Bạn Trẻ UNICEF'],
      suggestedActions: ['💬 Kể về bạn crush', '🍃 Bài tập thư giãn xoa dịu lòng', '📝 Viết một lá thư gửi chính mình'],
      safetyTriggered: false,
    };
  }

  // 10. TỰ TI NGOẠI HÌNH, BODY SHAMING, MỤN, BÉO, GẦY
  if (q.includes('ngoại hình') || q.includes('body shaming') || q.includes('mụn') || q.includes('béo') || q.includes('gầy') || q.includes('xấu') || q.includes('tự ti') || q.includes('chê bai')) {
    return {
      reply: `An An muốn ôm bạn một cái thật ấm áp 💙. Bạn tuyệt đối đừng để những lời chê bai ngoại hình làm bạn nghi ngờ vẻ đẹp độc bản của chính mình nhé!

Theo **Nghiên cứu về Tâm lý Học đường & Hình ảnh Bản thân (UNICEF)**:
1. **Cơ thể tuổi dậy thì đang biến đổi:** Mụn, sự thay đổi cân nặng hay chiều cao đều là sinh lý tự nhiên khi hormone đang điều chỉnh. Đây chỉ là một giai đoạn tạm thời.
2. **Bộ lọc trên mạng xã hội là giả:** 90% những bức ảnh da láng mịn, eo thon trên Instagram hay TikTok đều đã qua chỉnh sửa, ánh sáng và filter. Đừng đem thực tế của mình đi so sánh với sản phẩm đã qua xử lý của người khác.
3. **Quy tắc 5 giây:** Nếu một khuyết điểm trên cơ thể không thể thay đổi trong vòng 5 giây, không ai có quyền bình phẩm về nó. Những người thích chê bai người khác thường chỉ đang cố che giấu sự bất an của chính họ.
4. **Yêu thương cơ thể:** Hãy ăn ngủ đúng giờ, uống nhiều nước và chơi thể thao để cơ thể khỏe mạnh từ bên trong.

Bạn sinh ra là một phiên bản duy nhất trên Trái Đất này, hãy ngẩng cao đầu lên nhé!`,
      officialSources: ['Khuyến nghị UNICEF về Tâm lý Tuổi Dậy Thì', 'Viện Sức khỏe Tâm thần'],
      suggestedActions: ['✨ 3 điều tuyệt vời ở bản thân', '🍃 Hít thở sâu lấy lại tự tin', '💬 Kể cho An An nghe ai vừa chê bạn?'],
      safetyTriggered: false,
    };
  }

  // 11. BUỒN BÃ, TRỐNG RỖNG, CÔ ĐƠN, NGỘT NGẠT, MẤT ĐỘNG LỰC
  if (q.includes('buồn') || q.includes('cô đơn') || q.includes('trống rỗng') || q.includes('mệt') || q.includes('chán') || q.includes('ngột ngạt') || q.includes('mất động lực') || q.includes('khóc')) {
    return {
      reply: `An An gửi đến bạn một cái ôm thật dịu dàng 🌸. Những ngày thấy lòng trống rỗng, buồn bã hay muốn khóc mà chẳng biết vì sao thực ra là một tín hiệu cho thấy tâm trí bạn đang bị quá tải và cần được nghỉ ngơi.

Theo **Sổ tay Sơ cứu Tâm lý của WHO và Viện Sức khỏe Tâm thần**:
1. **Cho phép bản thân được buồn:** Đừng cố ép mình phải vui vẻ hay tích cực độc hại. Cảm xúc như những đợt sóng biển, bạn càng cố chống cự thì càng mệt, hãy cứ để nó cuộn trào rồi sẽ tự lắng xuống.
2. **Kỹ thuật neo đậu 5-4-3-2-1:** Tìm 5 đồ vật màu xanh, 4 bề mặt có thể chạm, 3 âm thanh nghe thấy, 2 mùi hương và 1 lời khen dành cho chính mình. Kỹ thuật này giúp xoa dịu hệ thần kinh giao cảm ngay lập tức.
3. **Uống một cốc nước ấm & rửa mặt bằng nước mát:** Thay đổi nhiệt độ cơ thể giúp kích hoạt hormone endorphin làm dịu căng thẳng.
4. **Tạm tắt mạng xã hội:** Mạng xã hội tràn ngập những hình ảnh hào nhoáng dễ khiến ta so sánh trong vô thức và cảm thấy kiệt quệ.

Bạn có muốn bật thử một chút âm thanh tiếng mưa rơi trên thanh công cụ và thở cùng An An vài nhịp không?`,
      officialSources: ['Tổ chức Y tế Thế giới (WHO)', 'Viện Sức khỏe Tâm thần - BV Bạch Mai'],
      suggestedActions: ['🍃 Bắt đầu bài tập thở 4-7-8', '🌧️ Bật âm thanh mưa thư giãn', '📝 Viết cảm xúc vào Sổ tay NLP'],
      safetyTriggered: false,
    };
  }

  // 12. MẤT NGỦ, KHÓ NGỦ, ÁC MỘNG, SUY NGHĨ NHIỀU BAN ĐÊM
  if (q.includes('ngủ') || q.includes('mất ngủ') || q.includes('ác mộng') || q.includes('thao thức') || q.includes('khó ngủ')) {
    return {
      reply: `Mất ngủ và suy nghĩ vẩn vơ vào ban đêm rất dễ làm ta kiệt sức vào sáng hôm sau. Khi căn phòng tối đi, não bộ thường hay phóng đại những nỗi sợ và sai lầm trong ngày 🌙.

Theo **Hiệp hội Giấc ngủ Quốc tế & Viện Sức khỏe Tâm thần**:
1. **Kỹ thuật Xả não (Brain Dump):** Lấy một cuốn sổ và viết ra giấy tất cả những gì bạn đang lo lắng hoặc danh sách việc ngày mai phải làm. Khi não biết mọi thứ đã được ghi lại, nó sẽ an tâm cho bạn ngủ.
2. **Nguyên tắc 20 phút:** Nếu nằm trên giường 20 phút mà chưa ngủ được, hãy rời giường, đi lại nhẹ nhàng hoặc đọc vài trang sách giấy dưới ánh đèn vàng. Tuyệt đối không cầm điện thoại lướt mạng xã hội (vì ánh sáng xanh sẽ chặn hormone ngủ Melatonin).
3. **Kỹ thuật Thư giãn cơ bắp tiến triển (PMR):** Nằm ngửa, lần lượt gồng chặt các ngón chân trong 5 giây rồi thả lỏng hoàn toàn; tiếp tục với bắp chân, đùi, bụng, vai và cơ mặt. Bạn sẽ thấy cơn buồn ngủ kéo đến rất nhanh.

Bây giờ bạn hãy nhắm mắt lại và hít thở thật chậm cùng An An nhé!`,
      officialSources: ['Hiệp hội Giấc ngủ Quốc tế', 'Viện Sức khỏe Tâm thần Bạch Mai'],
      suggestedActions: ['🍃 Tập thở 4-7-8 trước khi ngủ', '🌧️ Bật tiếng mưa đêm êm ái', '📝 Ghi nhật ký xả lo âu'],
      safetyTriggered: false,
    };
  }

  // 13. TỨC GIẬN, NỔI CÁU, MẤT BÌNH TĨNH
  if (q.includes('tức giận') || q.includes('bực') || q.includes('nổi cáu') || q.includes('cáu') || q.includes('đập phá') || q.includes('ức chế') || q.includes('muốn đánh')) {
    return {
      reply: `Cơn tức giận là một phản ứng phòng vệ hoàn toàn tự nhiên khi ranh giới hoặc quyền lợi của bạn bị xâm phạm 🔥. Bạn có quyền được tức giận, nhưng hãy để An An giúp bạn làm dịu ngọn lửa trong lòng để không nói hay làm điều gì gây hại cho chính bạn nhé!

Theo **Khoa học Não bộ & Kỹ thuật Điều hòa Cảm xúc**:
1. **Quy tắc Đếm chậm từ 1 đến 10:** Khi tức giận, hạch hạnh nhân (Amygdala) trong não chiếm quyền điều khiển và phong tỏa vỏ não tư duy. Việc dừng lại đếm chậm 10 giây giúp vỏ não lấy lại quyền kiểm soát.
2. **Uống một ngụm nước lạnh:** Uống nước lạnh kích thích dây thần kinh phế vị (Vagus Nerve) gửi tín hiệu hạ nhiệt tim đập và nhịp thở.
3. **Vận động giải phóng Adrenaline:** Đi bộ nhanh, vò nát một tờ giấy nháp hoặc đấm vào gối mềm. Đừng nén cơn giận, hãy xả năng lượng thừa ra ngoài một cách an toàn.

Bạn có muốn kể cho An An nghe điều gì vừa xảy ra làm bạn bực mình như vậy không?`,
      officialSources: ['Hội Tâm lý học Việt Nam', 'Viện Sức khỏe Tâm thần'],
      suggestedActions: ['🍃 Hít thở sâu 3 nhịp', '💬 Kể chi tiết điều làm bạn giận', '📝 Viết xả giận vào sổ tay'],
      safetyTriggered: false,
    };
  }

  // 14. BÀI TẬP THỞ, THƯ GIÃN, KỸ THUẬT 4-7-8, NEO ĐẬU
  if (q.includes('thở') || q.includes('4-7-8') || q.includes('neo đậu') || q.includes('thư giãn') || q.includes('hướng dẫn thở') || q.includes('yoga') || q.includes('thiền')) {
    return {
      reply: `Tuyệt vời! Tập thở là phương pháp y khoa nhanh nhất để kích hoạt hệ thần kinh phó giao cảm, làm giảm nhịp tim và cortisol (hormone căng thẳng) ngay tức thì 🍃.

**HƯỚNG DẪN KỸ THUẬT THỞ 4-7-8 CHUẨN:**
1. **Hít vào (4 giây):** Khép miệng, hít vào từ từ bằng mũi, cảm nhận bụng căng tròn ra.
2. **Giữ hơi (7 giây):** Nhẹ nhàng nín thở, giữ oxy lan tỏa trong lồng ngực.
3. **Thở ra (8 giây):** Thở ra thật chậm bằng miệng tạo thành tiếng thở êm ái, xẹp bụng xuống và tống khứ mọi mệt mỏi.

Lặp lại chu kỳ này 4 lần, bạn sẽ thấy cơ thể như được trút bỏ một tảng đá nặng trĩu. Bạn có thể bấm vào nút **"🍃 Tập Thở 4-7-8"** ở thanh menu trên cùng để theo dõi vòng tròn thở hoạt họa nhé!`,
      officialSources: ['Đại học Y khoa Harvard', 'Tổ chức Y tế Thế giới (WHO)'],
      suggestedActions: ['🍃 Mở vòng tròn thở 4-7-8', '🌧️ Bật âm thanh mưa thiền', '💬 Bạn thấy lồng ngực nhẹ hơn chưa?'],
      safetyTriggered: false,
    };
  }

  // 15. THÀNH TÍCH TỐT, VUI VẺ, CẢM ƠN, KHEN AN AN
  if (q.includes('cảm ơn') || q.includes('thank') || q.includes('vui') || q.includes('đạt giải') || q.includes('điểm cao') || q.includes('được điểm 10') || q.includes('được điểm 9') || q.includes('yêu an an') || q.includes('dễ thương')) {
    return {
      reply: `Ôi An An vui lây cùng bạn luôn nè! 🎉 Chúc mừng bạn vì những nỗ lực đã được đền đáp xứng đáng nhé!

Được đồng hành và nhìn thấy nụ cười của bạn là niềm hạnh phúc lớn nhất của An An 🌸. Đừng quên tự thưởng cho bản thân một ly trà sữa, một que kem hay một buổi tối thư giãn trọn vẹn nhé.

Hãy lưu giữ nguồn năng lượng tích cực này vào cuốn sổ tay cảm xúc để mỗi khi mệt mỏi, bạn có thể mở ra và nhớ rằng: **Bản thân mình đã từng rực rỡ và dũng cảm như thế nào!**`,
      officialSources: ['Tâm An SafeSpace', 'UNICEF Kỹ năng Tự trân trọng Bản thân'],
      suggestedActions: ['📝 Ghi lại niềm vui vào Sổ tay', '🌸 Chia sẻ niềm vui với bạn bè', '💬 Tâm sự thêm cùng An An'],
      safetyTriggered: false,
    };
  }

  // 16. KỂ CHUYỆN VUI, GIẢI TRÍ, TRUYỆN NGỤ NGÔN
  if (q.includes('kể chuyện') || q.includes('chuyện vui') || q.includes('truyện') || q.includes('thơ') || q.includes('joke') || q.includes('hài hước')) {
    return {
      reply: `An An tặng bạn một câu chuyện ngắn ấm áp về chú gấu nhỏ và chiếc ba lô nhé 🐻:

*Có một chú gấu con mỗi ngày đi học đều nhặt từng viên đá bên đường bỏ vào ba lô: một viên đá là lời trêu chọc của bạn khỉ, một viên đá là điểm kiểm tra chưa tốt, một viên đá là lời mắng của bố mẹ. Cứ thế, chiếc ba lô ngày càng nặng trĩu khiến chú gấu bước đi không nổi và bật khóc.*

*Bác Cú già bay qua thấy vậy bèn bảo: "Cháu hãy mở ba lô ra và nhìn xem, những viên đá này cháu nhặt làm gì? Chúng đâu phải là thức ăn hay đồ chơi của cháu!". Gấu con nhận ra và đổ hết đá ra bãi cỏ. Chú gấu nhẹ bẫng reo vui và chạy tung tăng dưới ánh hoàng hôn.*

**Bài học nhỏ:** Những lời phán xét hay muộn phiền cũng chỉ là những viên đá dọc đường. Bạn không có nghĩa vụ phải nhặt chúng bỏ vào lòng mình nhé 🌸!`,
      officialSources: ['Truyện ngụ ngôn Trị liệu Tâm lý Trẻ em - UNICEF'],
      suggestedActions: ['🍃 Hít một hơi thật nhẹ nhõm', '📝 Viết điều bạn muốn buông bỏ', '💬 Bạn thích câu chuyện này không?'],
      safetyTriggered: false,
    };
  }

  // 17. TỔNG QUÁT NĂNG ĐỘNG (DYNAMIC CONTEXTUAL SYNTHESIS)
  // Xử lý thông minh mọi câu hỏi độc lạ, phản chiếu cảm xúc và đưa ra gợi ý giải pháp
  return {
    reply: `An An rất trân trọng khi bạn chia sẻ điều này: *" ${queryText.length > 50 ? queryText.slice(0, 50) + '...' : queryText} "* 🌸.

Mỗi cảm xúc và câu hỏi của bạn đều hoàn toàn có lý do, và việc bạn dám đối diện, nói ra suy nghĩ của mình đã là một bước tiến rất tuyệt vời!

Theo góc nhìn khoa học tâm lý học đường:
1. **Lắng nghe nội tâm:** Khi gặp một tình huống bối rối hay khó xử, hãy tự hỏi bản thân: *"Điều gì đang khiến mình cảm thấy bất an nhất lúc này?"*.
2. **Tập trung vào điều bạn có thể kiểm soát:** Chúng ta không thể thay đổi suy nghĩ của người khác, nhưng chúng ta hoàn toàn có thể kiểm soát cách mình phản ứng, chăm sóc bản thân và bảo vệ ranh giới cá nhân.
3. **Không cô độc:** An An luôn ở đây 24/7. Dù là áp lực học tập, bất đồng bạn bè, chuyện gia đình hay tự vệ không gian mạng, bạn cứ thoải mái nhắn cho mình nhé.

Bạn có muốn chia sẻ cụ thể hơn chuyện này bắt đầu từ khi nào không nè?`,
    officialSources: ['UNICEF Việt Nam', 'Cục An toàn thông tin (Bộ TT&TT)', 'Tổng đài Quốc gia 111'],
    suggestedActions: ['🎓 Áp lực học tập & thi cử', '🛡️ Bị bêu rếu trên mạng xã hội', '🍃 Hướng dẫn tập thở xả stress'],
    safetyTriggered: false,
  };
}
